package com.atividade.meuperfil

import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.constraintlayout.widget.ConstraintLayout

class MainActivity : AppCompatActivity() {

    //tags para os logs
    private val TAG = "MainActivity"

    //Variaveis importantes
    private lateinit var imageViewProfile: ImageView
    private lateinit var rootLayout: ConstraintLayout
    private lateinit var tvNome: TextView
    private lateinit var tvProfissao: TextView
    private lateinit var tvBio: TextView
    private lateinit var btnLinkedIn: Button
    private lateinit var btnGitHub: Button
    private lateinit var btnDarkMode: Button

    private var isDarkMode = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        Log.d(TAG, "onCreate: Iniciando app meu perfil")

        //inicializando os componentes
        imageViewProfile = findViewById(R.id.imageViewProfile)
        rootLayout = findViewById(R.id.rootLayout)
        tvNome = findViewById(R.id.tvNome)
        tvProfissao = findViewById(R.id.tvProfissao)
        tvBio = findViewById(R.id.tvBio)
        btnLinkedIn = findViewById(R.id.btnLinkedIn)
        btnGitHub = findViewById(R.id.btnGitHub)
        btnDarkMode = findViewById(R.id.btnDarkMode)

        Log.d(TAG, "Componentes Inicializados")

        btnLinkedIn.setOnClickListener {
            Log.i(TAG,"botão linkedin clicado")
            abrirUrL("https://about.linkedin.com/pt-br")
        }
        btnGitHub.setOnClickListener {
            Log.i(TAG, "Botão Github clicado")
            abrirUrL("https://github.com/LucasStranger")
        }
        btnDarkMode.setOnClickListener {
            Log.i(TAG, "Botão DarkMode Clicado")
            alternarModoEscuro()
        }
    }

    private fun abrirUrL(url: String) {
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
        if (intent.resolveActivity(packageManager) != null) {
            startActivity(intent)
        } else {
            Log.e(TAG, "Não há navegador disponível")
        }
    }

    private fun alternarModoEscuro() {
        isDarkMode = !isDarkMode

        if (isDarkMode) {
            // Modo escuro
            rootLayout.setBackgroundColor(Color.parseColor("#121212")) // dark_bg
            tvNome.setTextColor(Color.parseColor("#E0E0E0"))           // dark_text
            tvProfissao.setTextColor(Color.parseColor("#E0E0E0"))
            tvBio.setTextColor(Color.parseColor("#E0E0E0"))
            btnDarkMode.text = "Modo Claro"
            Log.d(TAG, "Modo escuro ativado")
        } else {
            // Modo claro
            rootLayout.setBackgroundColor(Color.parseColor("#FFFFFF")) // branco
            tvNome.setTextColor(Color.parseColor("#000000"))           // preto
            tvProfissao.setTextColor(Color.parseColor("#000000"))
            tvBio.setTextColor(Color.parseColor("#000000"))
            btnDarkMode.text = "Modo Escuro"
            Log.d(TAG, "Modo claro ativado")
        }
    }
    override fun onStart() {
        super.onStart()
        Log.d(TAG, "onStart: tela visível")
    }

    override fun onResume() {
        super.onResume()
        Log.d(TAG, "onResume: app em foco")
    }

    override fun onPause() {
        super.onPause()
        Log.d(TAG, "onPause: app perdeu foco")
    }

    override fun onStop() {
        super.onStop()
        Log.d(TAG, "onStop: tela não visível")
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d(TAG, "onDestroy: app finalizado")
    }
}